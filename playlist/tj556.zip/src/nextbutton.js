import React from 'react';

const nextbutton = ({ onClick }) => {
  return (
    <button onClick={onClick}>Next</button>
  );
};

export default nextbutton;