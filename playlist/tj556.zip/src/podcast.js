

export function Podcast(props) {
  return (
    <div className="podcast">
      <p>Season: {props.season}, Episode: {props.episode} Episode Title: {props.episodeTitle}</p>
    </div>
  );
}


