import React from 'react';

const status = ({ statusText }) => {
  return (
    <div className="status">
      <p>{statusText}</p>
    </div>
  );
};

export default status;