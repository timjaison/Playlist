import React from 'react';

const previousbutton = ({ onClick }) => {
  return (
    <button onClick={onClick}>Previous</button>
  );
};

export default previousbutton;