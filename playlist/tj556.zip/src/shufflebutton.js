import React from 'react';

const shufflebutton = ({ onClick }) => {
  return (
    <button onClick={onClick}>Shuffle</button>
  );
};

export default shufflebutton;