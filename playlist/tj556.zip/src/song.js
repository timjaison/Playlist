// Song.js


export function Song(props) {
    return (
      <div className="song">
        <p>Title: {props.title} Artist: {props.artist}, year: {props.year}</p>
      </div>
    );
}
  


